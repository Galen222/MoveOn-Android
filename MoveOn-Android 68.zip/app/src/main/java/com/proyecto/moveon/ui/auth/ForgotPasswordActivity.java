package com.proyecto.moveon.ui.auth;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.proyecto.moveon.R;
import com.proyecto.moveon.core.api.ApiError;
import com.proyecto.moveon.core.i18n.AppLanguageManager;
import com.proyecto.moveon.core.theme.ThemeManager;
import com.proyecto.moveon.databinding.ActivityForgotPasswordBinding;
import com.proyecto.moveon.core.validation.AppInputValidator;
import com.proyecto.moveon.ui.common.TopSnackbar;
import com.proyecto.moveon.utils.NavigationUtils;
import com.proyecto.moveon.utils.StringUtils;

/**
 * Pantalla de recuperación de contraseña en dos pasos:
 *  - Paso 1: el usuario introduce su email → el backend envía un código.
 *  - Paso 2: el usuario introduce el código + nueva contraseña → el backend confirma el cambio.
 */
public class ForgotPasswordActivity extends AppCompatActivity {

    private static final String STATE_EMAIL_CONFIRMADO = "state_email_confirmado";
    private static final String STATE_IS_STEP_TWO = "state_is_step_two";

    private ActivityForgotPasswordBinding binding;
    private AuthViewModel viewModel;

    /** Email confirmado en el paso 1; se reutiliza en el paso 2. */
    private String emailConfirmado = "";

    /**
     * Indica si la UI está mostrando el paso 2.
     *
     * <p>Este valor se persiste para no volver siempre al paso 1 tras una recreación
     * de la activity (rotación, cambio de idioma, proceso reclamado por el sistema, etc.).</p>
     */
    private boolean isStepTwoVisible = false;

    /**
     * Aplica el idioma persistido antes de que Android cree la jerarquía visual.
     *
     * @param newBase contexto base entregado por el framework.
     */
    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(AppLanguageManager.wrapContext(newBase));
    }

    /**
     * Inicializa la pantalla, conecta el {@link AuthViewModel} y restaura el paso activo
     * del flujo de recuperación si la activity se recrea.
     *
     * @param savedInstanceState estado previo restaurado por Android, o {@code null} si es
     *                           la primera creación.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ThemeManager.applySavedTheme(this);
        super.onCreate(savedInstanceState);

        viewModel = new ViewModelProvider(this).get(AuthViewModel.class);

        binding = ActivityForgotPasswordBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setupListeners();
        observeViewModel();

        restoreUiState(savedInstanceState);
    }

    /**
     * Restaura el paso visible y el email confirmado tras recreaciones de la activity.
     */
    private void restoreUiState(@Nullable Bundle savedInstanceState) {
        if (savedInstanceState != null) {
            emailConfirmado = savedInstanceState.getString(STATE_EMAIL_CONFIRMADO, "");
            isStepTwoVisible = savedInstanceState.getBoolean(STATE_IS_STEP_TWO, false);
        }

        if (isStepTwoVisible && StringUtils.hasText(emailConfirmado)) {
            mostrarPaso2();
        } else {
            // Si no tenemos email confirmado válido, forzamos paso 1 para no dejar la UI
            // en un estado incoherente donde el usuario no pueda completar el reset.
            mostrarPaso1();
        }
    }

    // -------------------------------------------------------------------------
    // Listeners
    // -------------------------------------------------------------------------

    /**
     * Registra las interacciones de la UI para limpiar errores y disparar la acción adecuada
     * según el paso visible del flujo.
     */
    private void setupListeners() {
        binding.etEmail.setOnFocusChangeListener((v, f) -> {
            if (f) binding.tilEmail.setError(null);
        });
        binding.etCodigo.setOnFocusChangeListener((v, f) -> {
            if (f) binding.tilCodigo.setError(null);
        });
        binding.etPasswordNueva.setOnFocusChangeListener((v, f) -> {
            if (f) binding.tilPasswordNueva.setError(null);
        });
        binding.etPasswordConfirmar.setOnFocusChangeListener((v, f) -> {
            if (f) binding.tilPasswordConfirmar.setError(null);
        });

        binding.btnAccion.setOnClickListener(v -> {
            if (binding.tilCodigo.getVisibility() == View.VISIBLE) {
                attemptResetPassword();
            } else {
                attemptSolicitarCodigo();
            }
        });

        binding.btnVolverLogin.setOnClickListener(v ->
                NavigationUtils.goToActivityAndFinish(this, LoginActivity.class)
        );
    }

    // -------------------------------------------------------------------------
    // Observadores del ViewModel
    // -------------------------------------------------------------------------

    /**
     * Observa los estados expuestos por {@link AuthViewModel} para reflejar carga, errores y
     * transición entre el envío del código y el cambio efectivo de contraseña.
     */
    private void observeViewModel() {
        // Paso 1: respuesta de solicitar código
        viewModel.getForgotState().observe(this, state -> {
            if (state == null) return;

            if (state.loading) {
                setLoadingPaso1(true);
                return;
            }

            if (state.error != null) {
                setLoadingPaso1(false);
                applyBackendErrorsPaso1(state.error);
                if (!state.error.hasFieldErrors()) {
                    TopSnackbar.error(binding.getRoot(), state.error.getMessage());
                }
                viewModel.resetForgotState();
                return;
            }

            if (state.data != null) {
                setLoadingPaso1(false);
                TopSnackbar.success(binding.getRoot(),
                        getString(R.string.forgot_toast_codigo_enviado));
                binding.tilCodigo.setError(null);
                binding.tilPasswordNueva.setError(null);
                binding.tilPasswordConfirmar.setError(null);
                binding.etCodigo.setText(null);
                binding.etPasswordNueva.setText(null);
                binding.etPasswordConfirmar.setText(null);
                viewModel.resetForgotState();
                mostrarPaso2();
            }
        });

        // Paso 2: respuesta de resetear contraseña
        viewModel.getResetState().observe(this, state -> {
            if (state == null) return;

            if (state.loading) {
                setLoadingPaso2(true);
                return;
            }

            if (state.error != null) {
                setLoadingPaso2(false);
                applyBackendErrorsPaso2(state.error);
                if (!state.error.hasFieldErrors()) {
                    TopSnackbar.error(binding.getRoot(), state.error.getMessage());
                }
                viewModel.resetResetState();
                return;
            }

            if (state.data != null) {
                Toast.makeText(this, getString(R.string.forgot_toast_password_cambiada),
                        Toast.LENGTH_LONG).show();
                viewModel.resetResetState();
                NavigationUtils.goToActivityAndClearTask(this, LoginActivity.class);
            }
        });
    }

    // -------------------------------------------------------------------------
    // Validación y envío — Paso 1
    // -------------------------------------------------------------------------

    /**
     * Valida el email introducido y, si es correcto, solicita al backend el código de
     * recuperación que habilita el segundo paso del flujo.
     */
    private void attemptSolicitarCodigo() {
        binding.tilEmail.setError(null);

        AppInputValidator.ValidationResult<String> emailResult =
                AppInputValidator.validateEmail(this, StringUtils.textOf(binding.etEmail.getText()), true);

        if (!emailResult.isValid()) {
            binding.tilEmail.setError(emailResult.getErrorMessage());
            binding.etEmail.requestFocus();
            return;
        }

        emailConfirmado = emailResult.getValue();
        viewModel.solicitarRecuperacion(emailConfirmado);
    }

    // -------------------------------------------------------------------------
    // Validación y envío — Paso 2
    // -------------------------------------------------------------------------

    /**
     * Valida código y contraseñas del segundo paso antes de delegar en el
     * {@link AuthViewModel} el reseteo definitivo de la contraseña.
     */
    private void attemptResetPassword() {
        binding.tilCodigo.setError(null);
        binding.tilPasswordNueva.setError(null);
        binding.tilPasswordConfirmar.setError(null);

        AppInputValidator.ValidationResult<String> codigoResult =
                AppInputValidator.validateRecoveryCode(this, StringUtils.textOf(binding.etCodigo.getText()));
        AppInputValidator.ValidationResult<String> passwordResult =
                AppInputValidator.validatePassword(this, StringUtils.textOf(binding.etPasswordNueva.getText()), true, true);
        AppInputValidator.ValidationResult<String> confirmarPasswordResult =
                AppInputValidator.validatePasswordConfirmation(
                        this,
                        passwordResult.getValue(),
                        StringUtils.textOf(binding.etPasswordConfirmar.getText()),
                        R.string.forgot_error_passwords_distintas
                );

        boolean valid = true;

        if (!codigoResult.isValid()) {
            binding.tilCodigo.setError(codigoResult.getErrorMessage());
            valid = false;
        }

        if (!passwordResult.isValid()) {
            binding.tilPasswordNueva.setError(passwordResult.getErrorMessage());
            valid = false;
        }

        if (!confirmarPasswordResult.isValid()) {
            binding.tilPasswordConfirmar.setError(confirmarPasswordResult.getErrorMessage());
            valid = false;
        }

        if (!valid) return;

        viewModel.resetearPassword(emailConfirmado, codigoResult.getValue(), passwordResult.getValue());
    }

    // -------------------------------------------------------------------------
    // Aplicar errores de campo desde el backend
    // -------------------------------------------------------------------------

    /**
     * Traslada a la UI los errores de campo devueltos por el backend durante la solicitud del
     * código de recuperación.
     *
     * @param err error normalizado desde la capa remota.
     */
    private void applyBackendErrorsPaso1(ApiError err) {
        String emailMsg = err.firstFieldMessage("email", "correo");
        if (StringUtils.hasText(emailMsg)) binding.tilEmail.setError(emailMsg);
    }

    /**
     * Pinta en la UI los errores de validación asociados al cambio de contraseña.
     *
     * <p>Los errores ligados al email se muestran como snackbar porque el campo ya no está
     * visible en el segundo paso.</p>
     *
     * @param err error normalizado desde la capa remota.
     */
    private void applyBackendErrorsPaso2(ApiError err) {
        String codigoMsg = err.firstFieldMessage("codigo");
        String passwordMsg = err.firstFieldMessage("password");
        String emailMsg    = err.firstFieldMessage("email", "correo");

        if (StringUtils.hasText(codigoMsg))   binding.tilCodigo.setError(codigoMsg);
        if (StringUtils.hasText(passwordMsg)) binding.tilPasswordNueva.setError(passwordMsg);
        if (StringUtils.hasText(emailMsg))    TopSnackbar.error(binding.getRoot(), emailMsg);
    }

    // -------------------------------------------------------------------------
    // Control de visibilidad de pasos
    // -------------------------------------------------------------------------

    /**
     * Muestra el primer paso del flujo y sincroniza el estado restaurable asociado.
     */
    private void mostrarPaso1() {
        isStepTwoVisible = false;
        binding.tvDescripcion.setText(getString(R.string.forgot_description_step1));

        binding.tilEmail.setVisibility(View.VISIBLE);

        binding.tilCodigo.setVisibility(View.GONE);
        binding.tilPasswordNueva.setVisibility(View.GONE);
        binding.tilPasswordConfirmar.setVisibility(View.GONE);

        binding.btnAccion.setText(getString(R.string.forgot_btn_enviar_codigo));
    }

    /**
     * Muestra el segundo paso del flujo y sincroniza el estado restaurable asociado.
     */
    private void mostrarPaso2() {
        isStepTwoVisible = true;
        binding.tvDescripcion.setText(getString(R.string.forgot_description_step2));

        binding.tilEmail.setVisibility(View.GONE);

        binding.tilCodigo.setVisibility(View.VISIBLE);
        binding.tilPasswordNueva.setVisibility(View.VISIBLE);
        binding.tilPasswordConfirmar.setVisibility(View.VISIBLE);

        binding.btnAccion.setText(getString(R.string.forgot_btn_cambiar_password));
        binding.etCodigo.requestFocus();
    }

    // -------------------------------------------------------------------------
    // Control de estado de carga
    // -------------------------------------------------------------------------

    /**
     * Bloquea o reactiva los controles del primer paso mientras se tramita el envío del código.
     *
     * @param loading {@code true} para mostrar el estado de envío y deshabilitar la edición.
     */
    private void setLoadingPaso1(boolean loading) {
        binding.btnAccion.setEnabled(!loading);
        binding.btnVolverLogin.setEnabled(!loading);
        binding.tilEmail.setEnabled(!loading);
        binding.btnAccion.setText(loading
                ? getString(R.string.forgot_btn_enviando_codigo)
                : getString(R.string.forgot_btn_enviar_codigo));
    }

    /**
     * Bloquea o reactiva los controles del segundo paso mientras se confirma el nuevo password.
     *
     * @param loading {@code true} para mostrar el estado de cambio y evitar dobles envíos.
     */
    private void setLoadingPaso2(boolean loading) {
        binding.btnAccion.setEnabled(!loading);
        binding.btnVolverLogin.setEnabled(!loading);
        binding.tilCodigo.setEnabled(!loading);
        binding.tilPasswordNueva.setEnabled(!loading);
        binding.tilPasswordConfirmar.setEnabled(!loading);
        binding.btnAccion.setText(loading
                ? getString(R.string.forgot_btn_cambiando_password)
                : getString(R.string.forgot_btn_cambiar_password));
    }

    // -------------------------------------------------------------------------

    /**
     * Conserva el email confirmado y el paso actualmente visible para que el flujo pueda
     * reconstruirse tras recreaciones del sistema.
     *
     * @param outState bundle donde se persiste el estado transitorio de la pantalla.
     */
    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString(STATE_EMAIL_CONFIRMADO, emailConfirmado);
        outState.putBoolean(STATE_IS_STEP_TWO, isStepTwoVisible);
    }

    /**
     * Libera la referencia al binding cuando la activity se destruye definitivamente.
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        binding = null;
    }
}
